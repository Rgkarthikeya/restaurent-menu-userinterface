<!DOCTYPE html>
<html>
   <head>      
      <script type = "text/javascript">
                     function sayHello()
			 {
		               alert("Hello World")
           	 }
         </script>     
   </head>
   
   <body>
<input type = "button" onclick = "sayHello()" value = "Say Hello" />
   </body>  
</html>
